<?php
class Blogs_model extends CI_Model {
    public function __construct() {
        parent::__construct();
    }

    // Method to fetch blog records from the database
    public function getSome($numrec = 0) {
        if ($numrec == 0) {
            $query = $this->db->get('blogs');  // Fetch all blogs
        } else {
            $query = $this->db->get('blogs', $numrec);  // Fetch a limited number of blogs
        }
        
        return $query->result();  // Return the result of the query as an array of objects
    }
}
?>