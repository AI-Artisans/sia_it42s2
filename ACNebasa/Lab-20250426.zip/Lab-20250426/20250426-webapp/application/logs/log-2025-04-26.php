<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-04-26 04:35:44 --> Config Class Initialized
INFO - 2025-04-26 04:35:44 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:35:44 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:35:44 --> Utf8 Class Initialized
INFO - 2025-04-26 04:35:44 --> URI Class Initialized
INFO - 2025-04-26 04:35:44 --> Router Class Initialized
INFO - 2025-04-26 04:35:44 --> Output Class Initialized
INFO - 2025-04-26 04:35:44 --> Security Class Initialized
DEBUG - 2025-04-26 04:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:35:44 --> Input Class Initialized
INFO - 2025-04-26 04:35:44 --> Language Class Initialized
INFO - 2025-04-26 04:35:44 --> Loader Class Initialized
INFO - 2025-04-26 04:35:44 --> Database Driver Class Initialized
INFO - 2025-04-26 04:35:44 --> Controller Class Initialized
INFO - 2025-04-26 04:35:44 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:36:30 --> Config Class Initialized
INFO - 2025-04-26 04:36:30 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:36:30 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:36:30 --> Utf8 Class Initialized
INFO - 2025-04-26 04:36:30 --> URI Class Initialized
INFO - 2025-04-26 04:36:30 --> Router Class Initialized
INFO - 2025-04-26 04:36:30 --> Output Class Initialized
INFO - 2025-04-26 04:36:30 --> Security Class Initialized
DEBUG - 2025-04-26 04:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:36:30 --> Input Class Initialized
INFO - 2025-04-26 04:36:30 --> Language Class Initialized
INFO - 2025-04-26 04:36:30 --> Loader Class Initialized
INFO - 2025-04-26 04:36:30 --> Database Driver Class Initialized
INFO - 2025-04-26 04:36:30 --> Controller Class Initialized
INFO - 2025-04-26 04:36:30 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:36:43 --> Config Class Initialized
INFO - 2025-04-26 04:36:43 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:36:43 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:36:43 --> Utf8 Class Initialized
INFO - 2025-04-26 04:36:43 --> URI Class Initialized
INFO - 2025-04-26 04:36:43 --> Router Class Initialized
INFO - 2025-04-26 04:36:43 --> Output Class Initialized
INFO - 2025-04-26 04:36:43 --> Security Class Initialized
DEBUG - 2025-04-26 04:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:36:43 --> Input Class Initialized
INFO - 2025-04-26 04:36:43 --> Language Class Initialized
INFO - 2025-04-26 04:36:43 --> Loader Class Initialized
INFO - 2025-04-26 04:36:43 --> Database Driver Class Initialized
INFO - 2025-04-26 04:36:43 --> Controller Class Initialized
INFO - 2025-04-26 04:36:43 --> Model "Blogs_model" initialized
ERROR - 2025-04-26 04:36:43 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\20250426-webapp\application\views\msgview.php 57
INFO - 2025-04-26 04:36:43 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:36:43 --> Final output sent to browser
DEBUG - 2025-04-26 04:36:43 --> Total execution time: 0.0266
INFO - 2025-04-26 04:38:20 --> Config Class Initialized
INFO - 2025-04-26 04:38:20 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:38:20 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:38:20 --> Utf8 Class Initialized
INFO - 2025-04-26 04:38:20 --> URI Class Initialized
INFO - 2025-04-26 04:38:20 --> Router Class Initialized
INFO - 2025-04-26 04:38:20 --> Output Class Initialized
INFO - 2025-04-26 04:38:20 --> Security Class Initialized
DEBUG - 2025-04-26 04:38:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:38:20 --> Input Class Initialized
INFO - 2025-04-26 04:38:20 --> Language Class Initialized
INFO - 2025-04-26 04:38:20 --> Loader Class Initialized
INFO - 2025-04-26 04:38:20 --> Database Driver Class Initialized
INFO - 2025-04-26 04:38:20 --> Controller Class Initialized
INFO - 2025-04-26 04:38:20 --> Model "Blogs_model" initialized
ERROR - 2025-04-26 04:38:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\20250426-webapp\application\views\msgview.php 65
INFO - 2025-04-26 04:38:20 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:38:20 --> Final output sent to browser
DEBUG - 2025-04-26 04:38:20 --> Total execution time: 0.0314
INFO - 2025-04-26 04:44:05 --> Config Class Initialized
INFO - 2025-04-26 04:44:05 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:44:05 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:44:05 --> Utf8 Class Initialized
INFO - 2025-04-26 04:44:05 --> URI Class Initialized
INFO - 2025-04-26 04:44:05 --> Router Class Initialized
INFO - 2025-04-26 04:44:05 --> Output Class Initialized
INFO - 2025-04-26 04:44:05 --> Security Class Initialized
DEBUG - 2025-04-26 04:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:44:05 --> Input Class Initialized
INFO - 2025-04-26 04:44:05 --> Language Class Initialized
INFO - 2025-04-26 04:44:05 --> Loader Class Initialized
INFO - 2025-04-26 04:44:05 --> Database Driver Class Initialized
INFO - 2025-04-26 04:44:05 --> Controller Class Initialized
INFO - 2025-04-26 04:44:05 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:44:05 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:44:05 --> Final output sent to browser
DEBUG - 2025-04-26 04:44:05 --> Total execution time: 0.0307
INFO - 2025-04-26 04:46:12 --> Config Class Initialized
INFO - 2025-04-26 04:46:12 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:46:12 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:46:12 --> Utf8 Class Initialized
INFO - 2025-04-26 04:46:12 --> URI Class Initialized
INFO - 2025-04-26 04:46:12 --> Router Class Initialized
INFO - 2025-04-26 04:46:12 --> Output Class Initialized
INFO - 2025-04-26 04:46:12 --> Security Class Initialized
DEBUG - 2025-04-26 04:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:46:12 --> Input Class Initialized
INFO - 2025-04-26 04:46:12 --> Language Class Initialized
INFO - 2025-04-26 04:46:12 --> Loader Class Initialized
INFO - 2025-04-26 04:46:12 --> Database Driver Class Initialized
INFO - 2025-04-26 04:46:12 --> Controller Class Initialized
INFO - 2025-04-26 04:46:12 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:46:12 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:46:12 --> Final output sent to browser
DEBUG - 2025-04-26 04:46:12 --> Total execution time: 0.0170
INFO - 2025-04-26 04:50:01 --> Config Class Initialized
INFO - 2025-04-26 04:50:01 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:50:01 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:50:01 --> Utf8 Class Initialized
INFO - 2025-04-26 04:50:01 --> URI Class Initialized
INFO - 2025-04-26 04:50:01 --> Router Class Initialized
INFO - 2025-04-26 04:50:01 --> Output Class Initialized
INFO - 2025-04-26 04:50:01 --> Security Class Initialized
DEBUG - 2025-04-26 04:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:50:01 --> Input Class Initialized
INFO - 2025-04-26 04:50:01 --> Language Class Initialized
INFO - 2025-04-26 04:50:01 --> Loader Class Initialized
INFO - 2025-04-26 04:50:02 --> Database Driver Class Initialized
INFO - 2025-04-26 04:50:02 --> Controller Class Initialized
INFO - 2025-04-26 04:50:02 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:50:02 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:50:02 --> Final output sent to browser
DEBUG - 2025-04-26 04:50:02 --> Total execution time: 0.0179
INFO - 2025-04-26 04:50:04 --> Config Class Initialized
INFO - 2025-04-26 04:50:04 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:50:04 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:50:04 --> Utf8 Class Initialized
INFO - 2025-04-26 04:50:04 --> URI Class Initialized
INFO - 2025-04-26 04:50:04 --> Router Class Initialized
INFO - 2025-04-26 04:50:04 --> Output Class Initialized
INFO - 2025-04-26 04:50:04 --> Security Class Initialized
DEBUG - 2025-04-26 04:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:50:04 --> Input Class Initialized
INFO - 2025-04-26 04:50:04 --> Language Class Initialized
INFO - 2025-04-26 04:50:04 --> Loader Class Initialized
INFO - 2025-04-26 04:50:04 --> Database Driver Class Initialized
INFO - 2025-04-26 04:50:04 --> Controller Class Initialized
INFO - 2025-04-26 04:50:04 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:50:04 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:50:04 --> Final output sent to browser
DEBUG - 2025-04-26 04:50:04 --> Total execution time: 0.0489
INFO - 2025-04-26 04:50:32 --> Config Class Initialized
INFO - 2025-04-26 04:50:32 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:50:32 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:50:32 --> Utf8 Class Initialized
INFO - 2025-04-26 04:50:32 --> URI Class Initialized
INFO - 2025-04-26 04:50:32 --> Router Class Initialized
INFO - 2025-04-26 04:50:32 --> Output Class Initialized
INFO - 2025-04-26 04:50:32 --> Security Class Initialized
DEBUG - 2025-04-26 04:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:50:32 --> Input Class Initialized
INFO - 2025-04-26 04:50:32 --> Language Class Initialized
INFO - 2025-04-26 04:50:32 --> Loader Class Initialized
INFO - 2025-04-26 04:50:32 --> Database Driver Class Initialized
INFO - 2025-04-26 04:50:32 --> Controller Class Initialized
INFO - 2025-04-26 04:50:32 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:50:32 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:50:32 --> Final output sent to browser
DEBUG - 2025-04-26 04:50:32 --> Total execution time: 0.0380
INFO - 2025-04-26 04:51:14 --> Config Class Initialized
INFO - 2025-04-26 04:51:14 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:51:14 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:51:14 --> Utf8 Class Initialized
INFO - 2025-04-26 04:51:14 --> URI Class Initialized
INFO - 2025-04-26 04:51:14 --> Router Class Initialized
INFO - 2025-04-26 04:51:14 --> Output Class Initialized
INFO - 2025-04-26 04:51:14 --> Security Class Initialized
DEBUG - 2025-04-26 04:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:51:14 --> Input Class Initialized
INFO - 2025-04-26 04:51:14 --> Language Class Initialized
INFO - 2025-04-26 04:51:14 --> Loader Class Initialized
INFO - 2025-04-26 04:51:14 --> Database Driver Class Initialized
INFO - 2025-04-26 04:51:14 --> Controller Class Initialized
INFO - 2025-04-26 04:51:14 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:51:14 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:51:14 --> Final output sent to browser
DEBUG - 2025-04-26 04:51:14 --> Total execution time: 0.0184
INFO - 2025-04-26 04:53:26 --> Config Class Initialized
INFO - 2025-04-26 04:53:26 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:53:26 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:53:26 --> Utf8 Class Initialized
INFO - 2025-04-26 04:53:26 --> URI Class Initialized
INFO - 2025-04-26 04:53:26 --> Router Class Initialized
INFO - 2025-04-26 04:53:26 --> Output Class Initialized
INFO - 2025-04-26 04:53:26 --> Security Class Initialized
DEBUG - 2025-04-26 04:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:53:26 --> Input Class Initialized
INFO - 2025-04-26 04:53:26 --> Language Class Initialized
INFO - 2025-04-26 04:53:26 --> Loader Class Initialized
INFO - 2025-04-26 04:53:26 --> Database Driver Class Initialized
INFO - 2025-04-26 04:53:26 --> Controller Class Initialized
INFO - 2025-04-26 04:53:26 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:53:26 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:53:26 --> Final output sent to browser
DEBUG - 2025-04-26 04:53:26 --> Total execution time: 0.0309
INFO - 2025-04-26 04:53:27 --> Config Class Initialized
INFO - 2025-04-26 04:53:27 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:53:27 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:53:27 --> Utf8 Class Initialized
INFO - 2025-04-26 04:53:27 --> URI Class Initialized
INFO - 2025-04-26 04:53:27 --> Router Class Initialized
INFO - 2025-04-26 04:53:27 --> Output Class Initialized
INFO - 2025-04-26 04:53:27 --> Security Class Initialized
DEBUG - 2025-04-26 04:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:53:27 --> Input Class Initialized
INFO - 2025-04-26 04:53:27 --> Language Class Initialized
INFO - 2025-04-26 04:53:27 --> Loader Class Initialized
INFO - 2025-04-26 04:53:27 --> Database Driver Class Initialized
INFO - 2025-04-26 04:53:27 --> Controller Class Initialized
INFO - 2025-04-26 04:53:27 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:53:27 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:53:27 --> Final output sent to browser
DEBUG - 2025-04-26 04:53:27 --> Total execution time: 0.0364
INFO - 2025-04-26 04:53:28 --> Config Class Initialized
INFO - 2025-04-26 04:53:28 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:53:28 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:53:28 --> Utf8 Class Initialized
INFO - 2025-04-26 04:53:28 --> URI Class Initialized
INFO - 2025-04-26 04:53:28 --> Router Class Initialized
INFO - 2025-04-26 04:53:28 --> Output Class Initialized
INFO - 2025-04-26 04:53:28 --> Security Class Initialized
DEBUG - 2025-04-26 04:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:53:28 --> Input Class Initialized
INFO - 2025-04-26 04:53:28 --> Language Class Initialized
INFO - 2025-04-26 04:53:28 --> Loader Class Initialized
INFO - 2025-04-26 04:53:28 --> Database Driver Class Initialized
INFO - 2025-04-26 04:53:28 --> Controller Class Initialized
INFO - 2025-04-26 04:53:28 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:53:28 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:53:28 --> Final output sent to browser
DEBUG - 2025-04-26 04:53:28 --> Total execution time: 0.0330
INFO - 2025-04-26 04:56:18 --> Config Class Initialized
INFO - 2025-04-26 04:56:18 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:56:18 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:56:18 --> Utf8 Class Initialized
INFO - 2025-04-26 04:56:18 --> URI Class Initialized
INFO - 2025-04-26 04:56:18 --> Router Class Initialized
INFO - 2025-04-26 04:56:18 --> Output Class Initialized
INFO - 2025-04-26 04:56:18 --> Security Class Initialized
DEBUG - 2025-04-26 04:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:56:18 --> Input Class Initialized
INFO - 2025-04-26 04:56:18 --> Language Class Initialized
INFO - 2025-04-26 04:56:18 --> Loader Class Initialized
INFO - 2025-04-26 04:56:18 --> Database Driver Class Initialized
INFO - 2025-04-26 04:56:18 --> Controller Class Initialized
INFO - 2025-04-26 04:56:18 --> Model "Blogs_model" initialized
ERROR - 2025-04-26 04:56:18 --> Severity: Warning --> Undefined property: Activities::$blog C:\xampp\htdocs\20250426-webapp\application\controllers\activities.php 10
ERROR - 2025-04-26 04:56:18 --> Severity: error --> Exception: Call to a member function getSome() on null C:\xampp\htdocs\20250426-webapp\application\controllers\activities.php 10
INFO - 2025-04-26 04:56:31 --> Config Class Initialized
INFO - 2025-04-26 04:56:31 --> Hooks Class Initialized
DEBUG - 2025-04-26 04:56:31 --> UTF-8 Support Enabled
INFO - 2025-04-26 04:56:31 --> Utf8 Class Initialized
INFO - 2025-04-26 04:56:31 --> URI Class Initialized
INFO - 2025-04-26 04:56:31 --> Router Class Initialized
INFO - 2025-04-26 04:56:31 --> Output Class Initialized
INFO - 2025-04-26 04:56:31 --> Security Class Initialized
DEBUG - 2025-04-26 04:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 04:56:31 --> Input Class Initialized
INFO - 2025-04-26 04:56:31 --> Language Class Initialized
INFO - 2025-04-26 04:56:31 --> Loader Class Initialized
INFO - 2025-04-26 04:56:31 --> Database Driver Class Initialized
INFO - 2025-04-26 04:56:31 --> Controller Class Initialized
INFO - 2025-04-26 04:56:31 --> Model "Blogs_model" initialized
INFO - 2025-04-26 04:56:31 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 04:56:31 --> Final output sent to browser
DEBUG - 2025-04-26 04:56:31 --> Total execution time: 0.0385
INFO - 2025-04-26 05:06:30 --> Config Class Initialized
INFO - 2025-04-26 05:06:30 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:06:30 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:06:30 --> Utf8 Class Initialized
INFO - 2025-04-26 05:06:30 --> URI Class Initialized
INFO - 2025-04-26 05:06:30 --> Router Class Initialized
INFO - 2025-04-26 05:06:30 --> Output Class Initialized
INFO - 2025-04-26 05:06:30 --> Security Class Initialized
DEBUG - 2025-04-26 05:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:06:30 --> Input Class Initialized
INFO - 2025-04-26 05:06:30 --> Language Class Initialized
INFO - 2025-04-26 05:06:30 --> Loader Class Initialized
INFO - 2025-04-26 05:06:30 --> Database Driver Class Initialized
INFO - 2025-04-26 05:06:30 --> Controller Class Initialized
INFO - 2025-04-26 05:06:30 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:06:30 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:06:30 --> Final output sent to browser
DEBUG - 2025-04-26 05:06:30 --> Total execution time: 0.0175
INFO - 2025-04-26 05:06:52 --> Config Class Initialized
INFO - 2025-04-26 05:06:52 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:06:52 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:06:52 --> Utf8 Class Initialized
INFO - 2025-04-26 05:06:52 --> URI Class Initialized
INFO - 2025-04-26 05:06:52 --> Router Class Initialized
INFO - 2025-04-26 05:06:52 --> Output Class Initialized
INFO - 2025-04-26 05:06:52 --> Security Class Initialized
DEBUG - 2025-04-26 05:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:06:52 --> Input Class Initialized
INFO - 2025-04-26 05:06:52 --> Language Class Initialized
INFO - 2025-04-26 05:06:52 --> Loader Class Initialized
INFO - 2025-04-26 05:06:52 --> Database Driver Class Initialized
INFO - 2025-04-26 05:06:52 --> Controller Class Initialized
INFO - 2025-04-26 05:06:54 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\wsconsume.php
INFO - 2025-04-26 05:06:54 --> Final output sent to browser
DEBUG - 2025-04-26 05:06:54 --> Total execution time: 1.4511
INFO - 2025-04-26 05:10:01 --> Config Class Initialized
INFO - 2025-04-26 05:10:01 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:10:01 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:10:01 --> Utf8 Class Initialized
INFO - 2025-04-26 05:10:01 --> URI Class Initialized
INFO - 2025-04-26 05:10:01 --> Router Class Initialized
INFO - 2025-04-26 05:10:01 --> Output Class Initialized
INFO - 2025-04-26 05:10:01 --> Security Class Initialized
DEBUG - 2025-04-26 05:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:10:01 --> Input Class Initialized
INFO - 2025-04-26 05:10:01 --> Language Class Initialized
INFO - 2025-04-26 05:10:01 --> Loader Class Initialized
INFO - 2025-04-26 05:10:01 --> Database Driver Class Initialized
INFO - 2025-04-26 05:10:01 --> Controller Class Initialized
INFO - 2025-04-26 05:10:03 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\wsconsume.php
INFO - 2025-04-26 05:10:03 --> Final output sent to browser
DEBUG - 2025-04-26 05:10:03 --> Total execution time: 1.9411
INFO - 2025-04-26 05:10:39 --> Config Class Initialized
INFO - 2025-04-26 05:10:39 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:10:39 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:10:39 --> Utf8 Class Initialized
INFO - 2025-04-26 05:10:39 --> URI Class Initialized
INFO - 2025-04-26 05:10:39 --> Router Class Initialized
INFO - 2025-04-26 05:10:39 --> Output Class Initialized
INFO - 2025-04-26 05:10:39 --> Security Class Initialized
DEBUG - 2025-04-26 05:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:10:39 --> Input Class Initialized
INFO - 2025-04-26 05:10:39 --> Language Class Initialized
INFO - 2025-04-26 05:10:39 --> Loader Class Initialized
INFO - 2025-04-26 05:10:39 --> Database Driver Class Initialized
INFO - 2025-04-26 05:10:39 --> Controller Class Initialized
INFO - 2025-04-26 05:10:39 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:10:39 --> Final output sent to browser
DEBUG - 2025-04-26 05:10:39 --> Total execution time: 0.0175
INFO - 2025-04-26 05:13:30 --> Config Class Initialized
INFO - 2025-04-26 05:13:30 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:13:30 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:13:30 --> Utf8 Class Initialized
INFO - 2025-04-26 05:13:30 --> URI Class Initialized
INFO - 2025-04-26 05:13:30 --> Router Class Initialized
INFO - 2025-04-26 05:13:30 --> Output Class Initialized
INFO - 2025-04-26 05:13:30 --> Security Class Initialized
DEBUG - 2025-04-26 05:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:13:30 --> Input Class Initialized
INFO - 2025-04-26 05:13:30 --> Language Class Initialized
INFO - 2025-04-26 05:13:30 --> Loader Class Initialized
INFO - 2025-04-26 05:13:30 --> Database Driver Class Initialized
INFO - 2025-04-26 05:13:30 --> Controller Class Initialized
INFO - 2025-04-26 05:13:30 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:13:30 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:13:30 --> Final output sent to browser
DEBUG - 2025-04-26 05:13:30 --> Total execution time: 0.0174
INFO - 2025-04-26 05:13:31 --> Config Class Initialized
INFO - 2025-04-26 05:13:31 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:13:31 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:13:31 --> Utf8 Class Initialized
INFO - 2025-04-26 05:13:31 --> URI Class Initialized
INFO - 2025-04-26 05:13:31 --> Router Class Initialized
INFO - 2025-04-26 05:13:31 --> Output Class Initialized
INFO - 2025-04-26 05:13:31 --> Security Class Initialized
DEBUG - 2025-04-26 05:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:13:31 --> Input Class Initialized
INFO - 2025-04-26 05:13:31 --> Language Class Initialized
INFO - 2025-04-26 05:13:31 --> Loader Class Initialized
INFO - 2025-04-26 05:13:31 --> Database Driver Class Initialized
INFO - 2025-04-26 05:13:31 --> Controller Class Initialized
INFO - 2025-04-26 05:13:31 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:13:31 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:13:31 --> Final output sent to browser
DEBUG - 2025-04-26 05:13:31 --> Total execution time: 0.0190
INFO - 2025-04-26 05:17:44 --> Config Class Initialized
INFO - 2025-04-26 05:17:44 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:17:44 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:17:44 --> Utf8 Class Initialized
INFO - 2025-04-26 05:17:44 --> URI Class Initialized
INFO - 2025-04-26 05:17:44 --> Router Class Initialized
INFO - 2025-04-26 05:17:44 --> Output Class Initialized
INFO - 2025-04-26 05:17:44 --> Security Class Initialized
DEBUG - 2025-04-26 05:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:17:44 --> Input Class Initialized
INFO - 2025-04-26 05:17:44 --> Language Class Initialized
INFO - 2025-04-26 05:17:44 --> Loader Class Initialized
INFO - 2025-04-26 05:17:44 --> Database Driver Class Initialized
INFO - 2025-04-26 05:17:44 --> Controller Class Initialized
INFO - 2025-04-26 05:17:44 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:17:44 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:17:44 --> Final output sent to browser
DEBUG - 2025-04-26 05:17:44 --> Total execution time: 0.0322
INFO - 2025-04-26 05:18:15 --> Config Class Initialized
INFO - 2025-04-26 05:18:15 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:18:15 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:18:15 --> Utf8 Class Initialized
INFO - 2025-04-26 05:18:15 --> URI Class Initialized
INFO - 2025-04-26 05:18:15 --> Router Class Initialized
INFO - 2025-04-26 05:18:15 --> Output Class Initialized
INFO - 2025-04-26 05:18:15 --> Security Class Initialized
DEBUG - 2025-04-26 05:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:18:15 --> Input Class Initialized
INFO - 2025-04-26 05:18:15 --> Language Class Initialized
INFO - 2025-04-26 05:18:15 --> Loader Class Initialized
INFO - 2025-04-26 05:18:15 --> Database Driver Class Initialized
INFO - 2025-04-26 05:18:15 --> Controller Class Initialized
INFO - 2025-04-26 05:18:15 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:18:15 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:18:15 --> Final output sent to browser
DEBUG - 2025-04-26 05:18:15 --> Total execution time: 0.0392
INFO - 2025-04-26 05:18:21 --> Config Class Initialized
INFO - 2025-04-26 05:18:21 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:18:21 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:18:21 --> Utf8 Class Initialized
INFO - 2025-04-26 05:18:21 --> URI Class Initialized
INFO - 2025-04-26 05:18:21 --> Router Class Initialized
INFO - 2025-04-26 05:18:21 --> Output Class Initialized
INFO - 2025-04-26 05:18:21 --> Security Class Initialized
DEBUG - 2025-04-26 05:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:18:21 --> Input Class Initialized
INFO - 2025-04-26 05:18:21 --> Language Class Initialized
INFO - 2025-04-26 05:18:21 --> Loader Class Initialized
INFO - 2025-04-26 05:18:21 --> Database Driver Class Initialized
INFO - 2025-04-26 05:18:21 --> Controller Class Initialized
INFO - 2025-04-26 05:18:21 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:18:22 --> Final output sent to browser
DEBUG - 2025-04-26 05:18:22 --> Total execution time: 0.0269
INFO - 2025-04-26 05:19:10 --> Config Class Initialized
INFO - 2025-04-26 05:19:10 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:19:10 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:19:10 --> Utf8 Class Initialized
INFO - 2025-04-26 05:19:10 --> URI Class Initialized
INFO - 2025-04-26 05:19:10 --> Router Class Initialized
INFO - 2025-04-26 05:19:10 --> Output Class Initialized
INFO - 2025-04-26 05:19:10 --> Security Class Initialized
DEBUG - 2025-04-26 05:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:19:10 --> Input Class Initialized
INFO - 2025-04-26 05:19:10 --> Language Class Initialized
INFO - 2025-04-26 05:19:10 --> Loader Class Initialized
INFO - 2025-04-26 05:19:10 --> Database Driver Class Initialized
INFO - 2025-04-26 05:19:10 --> Controller Class Initialized
INFO - 2025-04-26 05:19:10 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:19:10 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:19:10 --> Final output sent to browser
DEBUG - 2025-04-26 05:19:10 --> Total execution time: 0.0333
INFO - 2025-04-26 05:19:14 --> Config Class Initialized
INFO - 2025-04-26 05:19:14 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:19:14 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:19:14 --> Utf8 Class Initialized
INFO - 2025-04-26 05:19:14 --> URI Class Initialized
INFO - 2025-04-26 05:19:14 --> Router Class Initialized
INFO - 2025-04-26 05:19:14 --> Output Class Initialized
INFO - 2025-04-26 05:19:14 --> Security Class Initialized
DEBUG - 2025-04-26 05:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:19:14 --> Input Class Initialized
INFO - 2025-04-26 05:19:14 --> Language Class Initialized
INFO - 2025-04-26 05:19:14 --> Loader Class Initialized
INFO - 2025-04-26 05:19:14 --> Database Driver Class Initialized
INFO - 2025-04-26 05:19:14 --> Controller Class Initialized
INFO - 2025-04-26 05:19:14 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:19:14 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:19:14 --> Final output sent to browser
DEBUG - 2025-04-26 05:19:14 --> Total execution time: 0.0167
INFO - 2025-04-26 05:19:23 --> Config Class Initialized
INFO - 2025-04-26 05:19:23 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:19:23 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:19:23 --> Utf8 Class Initialized
INFO - 2025-04-26 05:19:23 --> URI Class Initialized
INFO - 2025-04-26 05:19:23 --> Router Class Initialized
INFO - 2025-04-26 05:19:23 --> Output Class Initialized
INFO - 2025-04-26 05:19:23 --> Security Class Initialized
DEBUG - 2025-04-26 05:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:19:23 --> Input Class Initialized
INFO - 2025-04-26 05:19:23 --> Language Class Initialized
INFO - 2025-04-26 05:19:23 --> Loader Class Initialized
INFO - 2025-04-26 05:19:23 --> Database Driver Class Initialized
INFO - 2025-04-26 05:19:23 --> Controller Class Initialized
INFO - 2025-04-26 05:19:23 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:19:23 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:19:23 --> Final output sent to browser
DEBUG - 2025-04-26 05:19:23 --> Total execution time: 0.0368
INFO - 2025-04-26 05:19:26 --> Config Class Initialized
INFO - 2025-04-26 05:19:26 --> Hooks Class Initialized
DEBUG - 2025-04-26 05:19:26 --> UTF-8 Support Enabled
INFO - 2025-04-26 05:19:26 --> Utf8 Class Initialized
INFO - 2025-04-26 05:19:26 --> URI Class Initialized
INFO - 2025-04-26 05:19:26 --> Router Class Initialized
INFO - 2025-04-26 05:19:26 --> Output Class Initialized
INFO - 2025-04-26 05:19:26 --> Security Class Initialized
DEBUG - 2025-04-26 05:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-04-26 05:19:26 --> Input Class Initialized
INFO - 2025-04-26 05:19:26 --> Language Class Initialized
INFO - 2025-04-26 05:19:26 --> Loader Class Initialized
INFO - 2025-04-26 05:19:26 --> Database Driver Class Initialized
INFO - 2025-04-26 05:19:26 --> Controller Class Initialized
INFO - 2025-04-26 05:19:26 --> Model "Blogs_model" initialized
INFO - 2025-04-26 05:19:26 --> File loaded: C:\xampp\htdocs\20250426-webapp\application\views\msgview.php
INFO - 2025-04-26 05:19:26 --> Final output sent to browser
DEBUG - 2025-04-26 05:19:26 --> Total execution time: 0.0273
